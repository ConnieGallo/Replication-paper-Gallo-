
#########################################
### Export full table results         ###
#########################################



library(dplyr)
library(estimatr)
library(ggplot2)
library(tidyr)
library(huxtable)
library(here)

i_am("5_hte_models.R")

# load and recode (copied from results files) ####
dat <- read.csv(here("combined_dataset.csv"))

dat <- dat %>% 
  mutate(matched = case_when(is.na(posterior)~0,
                             T~1))

dat <- dat %>%
  mutate(sex = case_when(x_f_ch_male==1|x_f_ad_male==1~"M",
                         x_f_ch_male==0|x_f_ad_male==0~"F",
                         is.na(x_f_ch_male)&is.na(x_f_ad_male)&f_svy_gender=="M"~"M",
                         is.na(x_f_ch_male)&is.na(x_f_ad_male)&f_svy_gender=="F"~"F"))

dat <- dat %>%
  mutate(age_group = case_when((ra_year - f_svy_yob_imp_ytgc)>=13~"old_kid",
                               (ra_year - f_svy_yob_imp_ytgc)<13~"young_kid",
                               f_svy_sample2007 %in% c("AD", "ES")~"adult"))

#remove anyone without randomization group 
dat <- dat %>% filter(!is.na(ra_group)&!is.na(age_group))

#treat incorrect matches as non-matches
#if someone voted before age 18, set all to 0
dat$badmatch <- ifelse(!is.na(dat$r_pretreatturnout)&dat$age_group!="adult", 1, 0)

dat$matched <- ifelse(dat$badmatch==1, 0, dat$matched)

# set turnout to 0 if someone didn't match to the voter file
dat <- dat %>% 
  mutate(r_postturnout = case_when(matched==0~0,
                                   T~r_postturnout)) %>%
  mutate(r_pretreatturnout = case_when(matched==0~0,
                                       T~r_pretreatturnout))
dat$r_postturnout <- ifelse(is.na(dat$r_postturnout), 0, dat$r_postturnout)

# create ever voted indicator
dat <- dat %>%
  mutate(evervoted_post = case_when(r_postturnout>0~1,
                                    T~0)) %>%
  mutate(evervoted_pre = case_when(r_pretreatturnout>0~1,
                                   T~0))
dat <- dat %>%
  mutate(r_postturnout = case_when(badmatch==1~0,
                                   T~r_postturnout)) %>%
  mutate(r_pretreatturnout = case_when(badmatch==1~0,
                                       T~r_pretreatturnout)) %>%
  mutate(r_postregturnout = case_when(badmatch==1~NA_real_,
                                      T~r_postregturnout)) %>%
  mutate(evervoted_post = case_when(badmatch==1~0,
                                    T~evervoted_post)) %>%
  mutate(evervoted_pre = case_when(badmatch==1~0,
                                   T~evervoted_pre)) 


#covariates for control models
covs_ad <- c("x_f_ad_36_40", "x_f_ad_41_45", "x_f_ad_46_50",
             "x_f_ad_edged", "x_f_ad_edgradhs", "x_f_ad_edgradhs_miss", "x_f_ad_edinsch",
             "x_f_ad_ethn_hisp", "x_f_ad_le_35", "x_f_ad_male",
             "x_f_ad_nevmarr", "x_f_ad_parentu18", "x_f_ad_race_black", "x_f_ad_race_other", "x_f_ad_working",
             "x_f_hh_afdc", "x_f_hh_car", "x_f_hh_disabl", "x_f_hh_noteens",
             "x_f_hh_size2", "x_f_hh_size3", "x_f_hh_size4", "x_f_hh_victim",
             "x_f_hood_5y", "x_f_hood_chat", "x_f_hood_nbrkid", "x_f_hood_nofamily",
             "x_f_hood_nofriend", "x_f_hood_unsafenit", "x_f_hood_verydissat",
             "x_f_hous_fndapt", "x_f_hous_mov3tm", "x_f_hous_movdrgs", "x_f_hous_movschl", "x_f_hous_sec8bef",
             "x_f_site_balt", "x_f_site_bos", "x_f_site_chi", "x_f_site_la")



dat <- dat %>%
  mutate(race = case_when(x_f_ad_race_black==1~"black",
                          x_f_ad_ethn_hisp==1~"hisp",
                          x_f_ad_race_other==1&x_f_ad_ethn_hisp==0~"other",
                          T~"white"))

dat <- dat %>% rename("local_poverty_posttreat"=f_c9010t_perpov_dw)

dat <- dat %>%
  mutate(ad_educ = case_when(hed2==4~"no hs",
                             (hed2 %in% c(1,2))&hed3==5~"hs",
                             (hed4 %in% c(1,2))~"aa",
                             (hed4 %in% c(3,4))~"ba+" ))
dat$ad_educ <- factor(dat$ad_educ, 
                      levels=c("no hs", "hs", "aa", "ba+"),
                      ordered=T)

dat <- dat %>%
  mutate(yt_educ = case_when(yed3c==5&yed1==5~"no hs",
                             yed3c==1&(yed3a<=12)~"hs",
                             yed3a>12~"more than hs",
                             hho3 %in% c(1,2)~"hs",
                             hho3==3~"no hs",
                             hho4==1~"more than hs"))
dat$yt_educ <- factor(dat$yt_educ, 
                      levels=c("no hs", "hs", "more than hs"),
                      ordered=T)

dat <- dat %>%
  group_by(mto_pseudo_famid) %>%
  mutate(fam_moves = mean(a22, na.rm=T))





# run subsetted models and export ####

dat_full <- dat

# create_dfs 
boys <- dat %>% filter(sex=="M")
girls <- dat %>% filter(sex=="F")
black <- dat %>% filter(race=="black")
latino <- dat %>% filter(race=="hisp")
other <- dat %>% filter(race=="other")
baltimore <- dat %>% filter(ra_site==1)
boston <- dat %>% filter(ra_site==2)
chicago <- dat %>% filter(ra_site==3)
la <- dat %>% filter(ra_site==4)
nyc <- dat %>% filter(ra_site==5)

# repeat for each: girls, black, other:

dat <- girls
#dat <- black
#dat <- other


#table 1: matching to voter file/registration
mod1 <- lm_robust(matched~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(matched~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(matched~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)
huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Boston"="factor(ra_site)2",
                 "Site: Chicago"="factor(ra_site)3",
                 "Site: Los Angeles"="factor(ra_site)4",
                 "Site: New York City"="factor(ra_site)5")) %>%
  insert_row(c("Omitted site: Baltimore", "", "", "", "", "", ""), after=3) %>%
  set_caption("Voter registration/match rate by MTO treatment") %>%
  print_latex()

## table 2: voting rate posttreatment
mod1 <- lm_robust(r_postturnout~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(r_postturnout~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(r_postturnout~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Boston"="factor(ra_site)2",
                 "Site: Chicago"="factor(ra_site)3",
                 "Site: Los Angeles"="factor(ra_site)4",
                 "Site: New York City"="factor(ra_site)5")) %>%
  insert_row(c("Omitted site: Baltimore", "", "", "", "", "", ""), after=3) %>%
  set_caption("Post-treatment turnout rate by MTO treatment") %>%
  print_latex()


## table 3: predict ever voted posttreatment
mod1 <- lm_robust(evervoted_post~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(evervoted_post~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(evervoted_post~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Boston"="factor(ra_site)2",
                 "Site: Chicago"="factor(ra_site)3",
                 "Site: Los Angeles"="factor(ra_site)4",
                 "Site: New York City"="factor(ra_site)5")) %>%
  insert_row(c("Omitted site: Baltimore", "", "", "", "", "", ""), after=3) %>%
  set_caption("Voting at least once post-treatment by MTO treatment") %>%
  print_latex()


## table 4: voting rate postregistration
mod1 <- lm_robust(r_postregturnout~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(r_postregturnout~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(r_postregturnout~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Boston"="factor(ra_site)2",
                 "Site: Chicago"="factor(ra_site)3",
                 "Site: Los Angeles"="factor(ra_site)4",
                 "Site: New York City"="factor(ra_site)5")) %>%
  insert_row(c("Omitted site: Baltimore", "", "", "", "", "", ""), after=3) %>%
  set_caption("Turnout rate by MTO treatment, registered voters only") %>%
  print_latex()


# modified for boys (not enough adults for separate models):

dat <- boys


#table 1: matching to voter file/registration
mod2 <- lm_robust(matched~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(matched~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)
huxreg("Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Boston"="factor(ra_site)2",
                 "Site: Chicago"="factor(ra_site)3",
                 "Site: Los Angeles"="factor(ra_site)4",
                 "Site: New York City"="factor(ra_site)5")) %>%
  insert_row(c("Omitted site: Baltimore", "", "", "", ""), after=3) %>%
  set_caption("Voter registration/match rate by MTO treatment") %>%
  print_latex()


## table 2: voting rate posttreatment
mod2 <- lm_robust(r_postturnout~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(r_postturnout~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Boston"="factor(ra_site)2",
                 "Site: Chicago"="factor(ra_site)3",
                 "Site: Los Angeles"="factor(ra_site)4",
                 "Site: New York City"="factor(ra_site)5")) %>%
  insert_row(c("Omitted site: Baltimore", "", "", "", ""), after=3) %>%
  set_caption("Post-treatment turnout rate by MTO treatment") %>%
  print_latex()


## table 3: predict ever voted posttreatment
mod2 <- lm_robust(evervoted_post~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(evervoted_post~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Boston"="factor(ra_site)2",
                 "Site: Chicago"="factor(ra_site)3",
                 "Site: Los Angeles"="factor(ra_site)4",
                 "Site: New York City"="factor(ra_site)5")) %>%
  insert_row(c("Omitted site: Baltimore", "", "", "", ""), after=3) %>%
  set_caption("Voting at least once post-treatment by MTO treatment") %>%
  print_latex()


## table 4: voting rate postregistration
mod2 <- lm_robust(r_postregturnout~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(r_postregturnout~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg( "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
        statistics=c("N"="nobs", "R-squared"="r.squared"), 
        error_pos = "right",  
        note="Robust standard errors clustered by family.",
        coefs = c("Experimental group" = "ra_group_factorexperimental",
                  "Section 8 group" = "ra_group_factorsection 8",
                  "Site: Boston"="factor(ra_site)2",
                  "Site: Chicago"="factor(ra_site)3",
                  "Site: Los Angeles"="factor(ra_site)4",
                  "Site: New York City"="factor(ra_site)5")) %>%
  insert_row(c("Omitted site: Baltimore", "", "", "", ""), after=3) %>%
  set_caption("Turnout rate by MTO treatment, registered voters only") %>%
  print_latex()


# modified for latinos: (not enough in some site groups)

dat <- latino %>% filter(ra_site %in% c(2,4,5))

#table 1: matching to voter file/registration
mod1 <- lm_robust(matched~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(matched~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(matched~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)
huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Los Angeles"="factor(ra_site)4",
                 "Site: New York City"="factor(ra_site)5")) %>%
  insert_row(c("Omitted site: Boston", "", "", "", "", "", ""), after=3) %>%
  set_caption("Voter registration/match rate by MTO treatment") %>%
  print_latex()

## table 2: voting rate posttreatment
mod1 <- lm_robust(r_postturnout~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(r_postturnout~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(r_postturnout~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Los Angeles"="factor(ra_site)4",
                 "Site: New York City"="factor(ra_site)5")) %>%
  insert_row(c("Omitted site: Boston", "", "", "", "", "", ""), after=3) %>%
  set_caption("Post-treatment turnout rate by MTO treatment") %>%
  print_latex()


## table 3: predict ever voted posttreatment
mod1 <- lm_robust(evervoted_post~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(evervoted_post~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(evervoted_post~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Los Angeles"="factor(ra_site)4",
                 "Site: New York City"="factor(ra_site)5")) %>%
  insert_row(c("Omitted site: Boston", "", "", "", "", "", ""), after=3) %>%
  set_caption("Voting at least once post-treatment by MTO treatment") %>%
  print_latex()


## table 4: voting rate postregistration
mod1 <- lm_robust(r_postregturnout~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(r_postregturnout~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(r_postregturnout~ra_group_factor+factor(ra_site), weights=f_wt_totcore98, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Los Angeles"="factor(ra_site)4",
                 "Site: New York City"="factor(ra_site)5")) %>%
  insert_row(c("Omitted site: Boston", "", "", "", "", "", ""), after=3) %>%
  set_caption("Turnout rate by MTO treatment, registered voters only") %>%
  print_latex()



# repeat for site groups

#dat <- baltimore
#dat <- boston
#dat <- chicago
#dat <- la 
dat <- nyc

#table 1: matching to voter file/registration
mod1 <- lm_robust(matched~ra_group_factor, weights=f_wt_totcore98, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(matched~ra_group_factor, weights=f_wt_totcore98, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(matched~ra_group_factor, weights=f_wt_totcore98, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)
huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8")) %>%
  set_caption("Voter registration/match rate by MTO treatment") %>%
  print_latex()

## table 2: voting rate posttreatment
mod1 <- lm_robust(r_postturnout~ra_group_factor, weights=f_wt_totcore98, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(r_postturnout~ra_group_factor, weights=f_wt_totcore98, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(r_postturnout~ra_group_factor, weights=f_wt_totcore98, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8")) %>%
  set_caption("Post-treatment turnout rate by MTO treatment") %>%
  print_latex()


## table 3: predict ever voted posttreatment
mod1 <- lm_robust(evervoted_post~ra_group_factor, weights=f_wt_totcore98, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(evervoted_post~ra_group_factor, weights=f_wt_totcore98, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(evervoted_post~ra_group_factor, weights=f_wt_totcore98, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8")) %>%
  set_caption("Voting at least once post-treatment by MTO treatment") %>%
  print_latex()


## table 4: voting rate postregistration
mod1 <- lm_robust(r_postregturnout~ra_group_factor, weights=f_wt_totcore98, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(r_postregturnout~ra_group_factor, weights=f_wt_totcore98, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(r_postregturnout~ra_group_factor, weights=f_wt_totcore98, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8")) %>%
  set_caption("Turnout rate by MTO treatment, registered voters only") %>%
  print_latex()

