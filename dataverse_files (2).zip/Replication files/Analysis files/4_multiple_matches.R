library(dplyr)
library(estimatr)
library(ggplot2)
library(tidyr)
options(java.parameters = "-Xmx6g")
library(huxtable)
library(here)

i_am("4_multiple_matches.R")

# load and recode data ####

#load data
dat <- read.csv(here("combined_dataset_withdups.csv"))
#run rest of cleaning code (copied from results file)

dat <- dat %>% 
  mutate(matched = case_when(is.na(posterior)~0,
                             T~1))

dat <- dat %>%
  mutate(sex = case_when(x_f_ch_male==1|x_f_ad_male==1~"M",
                         x_f_ch_male==0|x_f_ad_male==0~"F",
                         is.na(x_f_ch_male)&is.na(x_f_ad_male)&f_svy_gender=="M"~"M",
                         is.na(x_f_ch_male)&is.na(x_f_ad_male)&f_svy_gender=="F"~"F"))

dat <- dat %>%
  mutate(age_group = case_when((ra_year - f_svy_yob_imp_ytgc)>=13~"old_kid",
                               (ra_year - f_svy_yob_imp_ytgc)<13~"young_kid",
                               f_svy_sample2007 %in% c("AD", "ES")~"adult"))

#remove anyone without randomization group 
dat <- dat %>% filter(!is.na(ra_group)&!is.na(age_group))

#treat incorrect matches as non-matches
#if someone voted before age 18, set all to 0
dat$badmatch <- ifelse(!is.na(dat$r_pretreatturnout)&dat$age_group!="adult", 1, 0)

dat$matched <- ifelse(dat$badmatch==1, 0, dat$matched)

# set turnout to 0 if someone didn't match to the voter file
dat <- dat %>% 
  mutate(r_postturnout = case_when(matched==0~0,
                                   T~r_postturnout)) %>%
  mutate(r_pretreatturnout = case_when(matched==0~0,
                                       T~r_pretreatturnout))
dat$r_postturnout <- ifelse(is.na(dat$r_postturnout), 0, dat$r_postturnout)

# create ever voted indicator
dat <- dat %>%
  mutate(evervoted_post = case_when(r_postturnout>0~1,
                                    T~0)) %>%
  mutate(evervoted_pre = case_when(r_pretreatturnout>0~1,
                                   T~0))
dat <- dat %>%
  mutate(r_postturnout = case_when(badmatch==1~0,
                                   T~r_postturnout)) %>%
  mutate(r_pretreatturnout = case_when(badmatch==1~0,
                                       T~r_pretreatturnout)) %>%
  mutate(r_postregturnout = case_when(badmatch==1~NA_real_,
                                      T~r_postregturnout)) %>%
  mutate(evervoted_post = case_when(badmatch==1~0,
                                    T~evervoted_post)) %>%
  mutate(evervoted_pre = case_when(badmatch==1~0,
                                   T~evervoted_pre)) 

#construct weights for each match
dat %>% 
  group_by(mto_pseudo_id) %>% 
  summarize(n=n()) %>% 
  group_by(n) %>% 
  summarize(n=n()) #%>%
#View()

dat <- dat %>% 
  group_by(mto_pseudo_id) %>% 
  mutate(matches=n())

dat <- dat %>% filter(badmatch==0|(badmatch==1&matches==1))

dat <- dat %>% 
  group_by(mto_pseudo_id) %>% 
  mutate(matches=n())

dat$posterior[dat$badmatch==1] <- NA
dat$postb <- ifelse(is.na(dat$posterior), 1, dat$posterior)
dat$weight <- dat$postb
dat <- dat %>% 
  group_by(mto_pseudo_id) %>%
  mutate(weight = weight/mean(weight)*1/matches)
dat$weight <- dat$weight*dat$f_wt_totcore98



#covariates for models with controls
covs_ad <- c("x_f_ad_36_40", "x_f_ad_41_45", "x_f_ad_46_50",
             "x_f_ad_edged", "x_f_ad_edgradhs", "x_f_ad_edgradhs_miss", "x_f_ad_edinsch",
             "x_f_ad_ethn_hisp", "x_f_ad_le_35", "x_f_ad_male",
             "x_f_ad_nevmarr", "x_f_ad_parentu18", "x_f_ad_race_black", "x_f_ad_race_other", "x_f_ad_working",
             "x_f_hh_afdc", "x_f_hh_car", "x_f_hh_disabl", "x_f_hh_noteens",
             "x_f_hh_size2", "x_f_hh_size3", "x_f_hh_size4", "x_f_hh_victim",
             "x_f_hood_5y", "x_f_hood_chat", "x_f_hood_nbrkid", "x_f_hood_nofamily",
             "x_f_hood_nofriend", "x_f_hood_unsafenit", "x_f_hood_verydissat",
             "x_f_hous_fndapt", "x_f_hous_mov3tm", "x_f_hous_movdrgs", "x_f_hous_movschl", "x_f_hous_sec8bef",
             "x_f_site_balt", "x_f_site_bos", "x_f_site_chi", "x_f_site_la")


dat <- dat %>%
  mutate(race = case_when(x_f_ad_race_black==1~"black",
                          x_f_ad_race_other==1~"other",
                          x_f_ad_ethn_hisp==1~"hisp",
                          T~"white"))

dat <- dat %>% rename("local_poverty_posttreat"=f_c9010t_perpov_dw)

dat <- dat %>%
  mutate(ad_educ = case_when(hed2==4~"no hs",
                             (hed2 %in% c(1,2))&hed3==5~"hs",
                             (hed4 %in% c(1,2))~"aa",
                             (hed4 %in% c(3,4))~"ba+" ))
dat$ad_educ <- factor(dat$ad_educ, 
                      levels=c("no hs", "hs", "aa", "ba+"),
                      ordered=T)

dat <- dat %>%
  mutate(yt_educ = case_when(yed3c==5&yed1==5~"no hs",
                             yed3c==1&(yed3a<=12)~"hs",
                             yed3a>12~"more than hs",
                             hho3 %in% c(1,2)~"hs",
                             hho3==3~"no hs",
                             hho4==1~"more than hs"))
dat$yt_educ <- factor(dat$yt_educ, 
                      levels=c("no hs", "hs", "more than hs"),
                      ordered=T)


# main outcome regression tables (Appendix tables A4.1-4) ####

## table 1: predict matching #
f1 <- as.formula(paste0("matched~", paste0(covs_ad, sep="+", collapse=""), "ra_group_factor"))
f2 <- as.formula(paste0("matched~", paste0(covs_ad, sep="+", collapse=""), "ra_group_factor"))
f3 <- as.formula(paste0("matched~", paste0(covs_ad, sep="+", collapse=""), "ra_group_factor"))

mod1 <- lm_robust(matched~ra_group_factor+factor(ra_site), weights=weight, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(matched~ra_group_factor+factor(ra_site), weights=weight, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(matched~ra_group_factor+factor(ra_site), weights=weight, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Boston"="factor(ra_site)2",
                 "Site: Chicago"="factor(ra_site)3",
                 "Site: Los Angeles"="factor(ra_site)4",
                 "Site: New York City"="factor(ra_site)5")) %>%
  insert_row(c("Omitted site: Baltimore", "", "", "", "", "", ""), after=3) %>%
  set_caption("Voter registration/match rate by MTO treatment") %>%
  print_latex()


mod1 <- lm_robust(f1, weights=weight, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(f2, weights=weight, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(f3, weights=weight, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Baltimore"="x_f_site_balt",
                 "Site: Boston"="x_f_site_bos",
                 "Site: Chicago"="x_f_site_chi",
                 "Site: Los Angeles"="x_f_site_la",
                 "Adult age 36-40"="x_f_ad_36_40",
                 "Adult age 41-45"="x_f_ad_41_45",
                 "Adult age 46-50"="x_f_ad_46_50",
                 "Adult educ: GED"="x_f_ad_edged",
                 "Adult educ: HS Grad"="x_f_ad_edgradhs",
                 "Adult educ: Missing"="x_f_ad_edgradhs_miss",
                 "Adult educ: In School"="x_f_ad_edinsch",
                 "Adult ethnic: Hispanic"="x_f_ad_ethn_hisp",
                 "Adult race: Black"="x_f_ad_race_black",
                 "Adult race: other"="x_f_ad_race_other",
                 "Adult never married"="x_f_ad_nevmarr",
                 "Adult <18 at first child"="x_f_ad_parentu18",
                 "Adult working"="x_f_ad_working",
                 "HH on AFDC"="x_f_hh_afdc",
                 "HH has car"="x_f_hh_car",
                 "HH member with disability"="x_f_hh_disabl",
                 "No teens in HH"="x_f_hh_noteens",
                 "HH size <=2"="x_f_hh_size2",
                 "HH size 3"="x_f_hh_size3",
                 "HH size 4"="x_f_hh_size4",
                 "HH cont. recent crime victim"="x_f_hh_victim",
                 "HH head in nbhd 5+ years"="x_f_hood_5y",
                 "HH head chats w/ nbs often"="x_f_hood_chat",
                 "HH head would tell on nbhd kid"="x_f_hood_nbrkid",
                 "HH head no family in nbhd"="x_f_hood_nofamily",
                 "HH head no friends in nbhd"="x_f_hood_nofriend",
                 "HH head feels nbhd unsafe at night"="x_f_hood_unsafenit",
                 "HH head very dissat w. nbhd"="x_f_hood_verydissat",
                 "HH head sure can find apt"="x_f_hous_fndapt",
                 "HH head moved >3x in 5 yrs"="x_f_hous_mov3tm",
                 "Top moving reason: drugs/crime"="x_f_hous_movdrgs",
                 "Top moving reason: schools"="x_f_hous_movschl",
                 "HH head applied for s8 before"="x_f_hous_sec8bef")) %>%
  insert_row(c("Omitted site: New York City", "", "", "", "", "", ""), after=3) %>%
  set_caption("Voter registration/match rate by MTO treatment") %>%
  print_latex()




## table 2: voting rate posttreatment
f1 <- as.formula(paste0("r_postturnout~", paste0(covs_ad, sep="+", collapse=""), "ra_group_factor"))
f2 <- as.formula(paste0("r_postturnout~", paste0(covs_ad, sep="+", collapse=""), "ra_group_factor"))
f3 <- as.formula(paste0("r_postturnout~", paste0(covs_ad, sep="+", collapse=""), "ra_group_factor"))

mod1 <- lm_robust(r_postturnout~ra_group_factor+factor(ra_site), weights=weight, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(r_postturnout~ra_group_factor+factor(ra_site), weights=weight, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(r_postturnout~ra_group_factor+factor(ra_site), weights=weight, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Boston"="factor(ra_site)2",
                 "Site: Chicago"="factor(ra_site)3",
                 "Site: Los Angeles"="factor(ra_site)4",
                 "Site: New York City"="factor(ra_site)5")) %>%
  insert_row(c("Omitted site: Baltimore", "", "", "", "", "", ""), after=3) %>%
  set_caption("Post-treatment turnout rate by MTO treatment") %>%
  print_latex()

mod1 <- lm_robust(f1, weights=weight, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(f2, weights=weight, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(f3, weights=weight, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Baltimore"="x_f_site_balt",
                 "Site: Boston"="x_f_site_bos",
                 "Site: Chicago"="x_f_site_chi",
                 "Site: Los Angeles"="x_f_site_la",
                 "Adult age 36-40"="x_f_ad_36_40",
                 "Adult age 41-45"="x_f_ad_41_45",
                 "Adult age 46-50"="x_f_ad_46_50",
                 "Adult educ: GED"="x_f_ad_edged",
                 "Adult educ: HS Grad"="x_f_ad_edgradhs",
                 "Adult educ: Missing"="x_f_ad_edgradhs_miss",
                 "Adult educ: In School"="x_f_ad_edinsch",
                 "Adult ethnic: Hispanic"="x_f_ad_ethn_hisp",
                 "Adult race: Black"="x_f_ad_race_black",
                 "Adult race: other"="x_f_ad_race_other",
                 "Adult never married"="x_f_ad_nevmarr",
                 "Adult <18 at first child"="x_f_ad_parentu18",
                 "Adult working"="x_f_ad_working",
                 "HH on AFDC"="x_f_hh_afdc",
                 "HH has car"="x_f_hh_car",
                 "HH member with disability"="x_f_hh_disabl",
                 "No teens in HH"="x_f_hh_noteens",
                 "HH size <=2"="x_f_hh_size2",
                 "HH size 3"="x_f_hh_size3",
                 "HH size 4"="x_f_hh_size4",
                 "HH cont. recent crime victim"="x_f_hh_victim",
                 "HH head in nbhd 5+ years"="x_f_hood_5y",
                 "HH head chats w/ nbs often"="x_f_hood_chat",
                 "HH head would tell on nbhd kid"="x_f_hood_nbrkid",
                 "HH head no family in nbhd"="x_f_hood_nofamily",
                 "HH head no friends in nbhd"="x_f_hood_nofriend",
                 "HH head feels nbhd unsafe at night"="x_f_hood_unsafenit",
                 "HH head very dissat w. nbhd"="x_f_hood_verydissat",
                 "HH head sure can find apt"="x_f_hous_fndapt",
                 "HH head moved >3x in 5 yrs"="x_f_hous_mov3tm",
                 "Top moving reason: drugs/crime"="x_f_hous_movdrgs",
                 "Top moving reason: schools"="x_f_hous_movschl",
                 "HH head applied for s8 before"="x_f_hous_sec8bef")) %>%
  insert_row(c("Omitted site: New York City", "", "", "", "", "", ""), after=3) %>%
  set_caption("Post-treatment turnout rate by MTO treatment") %>%
  print_latex()


## table 3: predict ever voted posttreatment
f1 <- as.formula(paste0("evervoted_post~", paste0(covs_ad, sep="+", collapse=""), "ra_group_factor"))
f2 <- as.formula(paste0("evervoted_post~", paste0(covs_ad, sep="+", collapse=""), "ra_group_factor"))
f3 <- as.formula(paste0("evervoted_post~", paste0(covs_ad, sep="+", collapse=""), "ra_group_factor"))

mod1 <- lm_robust(evervoted_post~ra_group_factor+factor(ra_site), weights=weight, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(evervoted_post~ra_group_factor+factor(ra_site), weights=weight, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(evervoted_post~ra_group_factor+factor(ra_site), weights=weight, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Boston"="factor(ra_site)2",
                 "Site: Chicago"="factor(ra_site)3",
                 "Site: Los Angeles"="factor(ra_site)4",
                 "Site: New York City"="factor(ra_site)5")) %>%
  insert_row(c("Omitted site: Baltimore", "", "", "", "", "", ""), after=3) %>%
  set_caption("Voting at least once post-treatment by MTO treatment") %>%
  print_latex()


mod1 <- lm_robust(f1, weights=weight, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(f2, weights=weight, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(f3, weights=weight, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)


huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Baltimore"="x_f_site_balt",
                 "Site: Boston"="x_f_site_bos",
                 "Site: Chicago"="x_f_site_chi",
                 "Site: Los Angeles"="x_f_site_la",
                 "Adult age 36-40"="x_f_ad_36_40",
                 "Adult age 41-45"="x_f_ad_41_45",
                 "Adult age 46-50"="x_f_ad_46_50",
                 "Adult educ: GED"="x_f_ad_edged",
                 "Adult educ: HS Grad"="x_f_ad_edgradhs",
                 "Adult educ: Missing"="x_f_ad_edgradhs_miss",
                 "Adult educ: In School"="x_f_ad_edinsch",
                 "Adult ethnic: Hispanic"="x_f_ad_ethn_hisp",
                 "Adult race: Black"="x_f_ad_race_black",
                 "Adult race: other"="x_f_ad_race_other",
                 "Adult never married"="x_f_ad_nevmarr",
                 "Adult <18 at first child"="x_f_ad_parentu18",
                 "Adult working"="x_f_ad_working",
                 "HH on AFDC"="x_f_hh_afdc",
                 "HH has car"="x_f_hh_car",
                 "HH member with disability"="x_f_hh_disabl",
                 "No teens in HH"="x_f_hh_noteens",
                 "HH size <=2"="x_f_hh_size2",
                 "HH size 3"="x_f_hh_size3",
                 "HH size 4"="x_f_hh_size4",
                 "HH cont. recent crime victim"="x_f_hh_victim",
                 "HH head in nbhd 5+ years"="x_f_hood_5y",
                 "HH head chats w/ nbs often"="x_f_hood_chat",
                 "HH head would tell on nbhd kid"="x_f_hood_nbrkid",
                 "HH head no family in nbhd"="x_f_hood_nofamily",
                 "HH head no friends in nbhd"="x_f_hood_nofriend",
                 "HH head feels nbhd unsafe at night"="x_f_hood_unsafenit",
                 "HH head very dissat w. nbhd"="x_f_hood_verydissat",
                 "HH head sure can find apt"="x_f_hous_fndapt",
                 "HH head moved >3x in 5 yrs"="x_f_hous_mov3tm",
                 "Top moving reason: drugs/crime"="x_f_hous_movdrgs",
                 "Top moving reason: schools"="x_f_hous_movschl",
                 "HH head applied for s8 before"="x_f_hous_sec8bef")) %>%
  insert_row(c("Omitted site: New York City", "", "", "", "", "", ""), after=3) %>%
  set_caption("Voting at least once post-treatment by MTO treatment") %>%
  print_latex()

## table 4: voting rate postregistration
f1 <- as.formula(paste0("r_postregturnout~", paste0(covs_ad, sep="+", collapse=""), "ra_group_factor"))
f2 <- as.formula(paste0("r_postregturnout~", paste0(covs_ad, sep="+", collapse=""), "ra_group_factor"))
f3 <- as.formula(paste0("r_postregturnout~", paste0(covs_ad, sep="+", collapse=""), "ra_group_factor"))

mod1 <- lm_robust(r_postregturnout~ra_group_factor+factor(ra_site), weights=weight, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(r_postregturnout~ra_group_factor+factor(ra_site), weights=weight, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(r_postregturnout~ra_group_factor+factor(ra_site), weights=weight, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Boston"="factor(ra_site)2",
                 "Site: Chicago"="factor(ra_site)3",
                 "Site: Los Angeles"="factor(ra_site)4",
                 "Site: New York City"="factor(ra_site)5")) %>%
  insert_row(c("Omitted site: Baltimore", "", "", "", "", "", ""), after=3) %>%
  set_caption("Turnout rate by MTO treatment, registered voters only") %>%
  print_latex()

mod1 <- lm_robust(f1, weights=weight, data=dat[dat$age_group=="adult",], clusters = mto_pseudo_famid)
mod2 <- lm_robust(f2, weights=weight, data=dat[dat$age_group=="old_kid",], clusters = mto_pseudo_famid)
mod3 <- lm_robust(f3, weights=weight, data=dat[dat$age_group=="young_kid",], clusters = mto_pseudo_famid)

huxreg("Adults"=mod1, "Age 13-19 at baseline"=mod2, "Age 0-12 at baseline"=mod3, 
       statistics=c("N"="nobs", "R-squared"="r.squared"), 
       error_pos = "right",  
       note="Robust standard errors clustered by family.",
       coefs = c("Experimental group" = "ra_group_factorexperimental",
                 "Section 8 group" = "ra_group_factorsection 8",
                 "Site: Baltimore"="x_f_site_balt",
                 "Site: Boston"="x_f_site_bos",
                 "Site: Chicago"="x_f_site_chi",
                 "Site: Los Angeles"="x_f_site_la",
                 "Adult age 36-40"="x_f_ad_36_40",
                 "Adult age 41-45"="x_f_ad_41_45",
                 "Adult age 46-50"="x_f_ad_46_50",
                 "Adult educ: GED"="x_f_ad_edged",
                 "Adult educ: HS Grad"="x_f_ad_edgradhs",
                 "Adult educ: Missing"="x_f_ad_edgradhs_miss",
                 "Adult educ: In School"="x_f_ad_edinsch",
                 "Adult ethnic: Hispanic"="x_f_ad_ethn_hisp",
                 "Adult race: Black"="x_f_ad_race_black",
                 "Adult race: other"="x_f_ad_race_other",
                 "Adult never married"="x_f_ad_nevmarr",
                 "Adult <18 at first child"="x_f_ad_parentu18",
                 "Adult working"="x_f_ad_working",
                 "HH on AFDC"="x_f_hh_afdc",
                 "HH has car"="x_f_hh_car",
                 "HH member with disability"="x_f_hh_disabl",
                 "No teens in HH"="x_f_hh_noteens",
                 "HH size <=2"="x_f_hh_size2",
                 "HH size 3"="x_f_hh_size3",
                 "HH size 4"="x_f_hh_size4",
                 "HH cont. recent crime victim"="x_f_hh_victim",
                 "HH head in nbhd 5+ years"="x_f_hood_5y",
                 "HH head chats w/ nbs often"="x_f_hood_chat",
                 "HH head would tell on nbhd kid"="x_f_hood_nbrkid",
                 "HH head no family in nbhd"="x_f_hood_nofamily",
                 "HH head no friends in nbhd"="x_f_hood_nofriend",
                 "HH head feels nbhd unsafe at night"="x_f_hood_unsafenit",
                 "HH head very dissat w. nbhd"="x_f_hood_verydissat",
                 "HH head sure can find apt"="x_f_hous_fndapt",
                 "HH head moved >3x in 5 yrs"="x_f_hous_mov3tm",
                 "Top moving reason: drugs/crime"="x_f_hous_movdrgs",
                 "Top moving reason: schools"="x_f_hous_movschl",
                 "HH head applied for s8 before"="x_f_hous_sec8bef")) %>%
  insert_row(c("Omitted site: New York City", "", "", "", "", "", ""), after=3) %>%
  set_caption("Turnout rate by MTO treatment, registered voters only") %>%
  print_latex()
