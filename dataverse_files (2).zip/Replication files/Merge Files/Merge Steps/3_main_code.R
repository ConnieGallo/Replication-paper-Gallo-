

require(fastLink)
require(data.table)
require(rstudioapi)
require(here)

i_am("3_main_code.R")
rm(list=ls())


# set primary directory and folders
destination <- here()

# set working directory
setwd(destination) 

# set primary directory and folders
temp.folder <- paste0(destination,'temporary_files/')

# to store match pieces
dir.create(paste0(temp.folder,'small_match/'))


# create index for match status, etc.
match.groups <- data.frame(group=c("small.match.male",
                   "small.match.female",
                   "main.match.male",
                   "main.match.female"),
                   size=c("small_clusters","small_clusters","main_clusters","main_clusters"),
                   gender=c("male","female","male","female"),status=NA)

### for initial test:
#match.groups <- match.groups[1,]


##### run code ####
source("match_function.R")

# set starting values
i <- 1
cluster.range <- NULL
voter.sub <- NULL
mto.sub <- NULL

match_cluster(i=i,match.groups=match.groups,
              cluster.range=cluster.range,
              voter.sub=cluster.range,
              mto.sub=cluster.range,
              temp.folder=temp.folder)
